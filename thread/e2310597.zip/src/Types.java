enum Types {
    IRON,
    COPPER,
    LIMESTONE,
    MINER,
    SMELTER,
    CONSTRUCTOR,
}